This is the GTK2 Clearlooks theme engine, for both 32-bit and
64-bit Windows OSes, as distributed in Partha's Gimp 2.8.14
builds ( http://www.partha.com/ ).

Since many Gimp2 themes use this engine, you may want to make it
available through your official Windows installation of Gimp2.

Depending on whether you have installed the 32-bit or the 64-bit version
of Gimp2, and assuming you have not changed the default path during its
installation, copy...

either the file: x86\libclearlooks.dll (for 32-bit installations)
or the file    : x64\libclearlooks.dll (for 64-bit installations)

into the folder: C:\Program Files\GIMP 2\lib\gtk-2.0\2.10.0\engines\

That's all. Now the Clearlooks GTK2 engine will be available to any Gimp2
theme that requires it.

PS. If you are on Linux or Mac with a Gnome 2 (GTK2) theme, chances are
that the Clearlooks theming engine is already installed on your system. If
not, you need to install the "gtk2-engines" or the "gtk2-engines-clearlooks"
package for your specific distro. If you only have GTK3 installed, first you
will need to install GTK2 too (they can co-exist). If none of the above works,
you may need to do some googling.

